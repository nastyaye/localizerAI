import openai

openai.api_key = "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"

response = openai.audio.speech.create(
    model="tts-1",              # OpenAI TTS model
    voice="nova",                # Choose voice: nova, echo, fable, alloy, onyx, shimmer
    input="Enjoying homemade meals has never been easier. Simply pick your favorite recipes online, have fresh, pre-portioned ingredients delivered to your doorstep, and you can create delicious dishes right in your own kitchen.",
    speed=1.3
)

# Save the output as an audio file
with open("voiceover.mp3", "wb") as f:
    f.write(response.content)