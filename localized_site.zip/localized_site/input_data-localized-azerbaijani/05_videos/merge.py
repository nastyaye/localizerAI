from moviepy import *
videoclip = VideoFileClip("C:\\Users\\mika0\\OneDrive\\Рабочий стол\\NotHelloFresh\\project\\public\\videos\\cooking.mp4")
audioclip = AudioFileClip("voiceover.mp3")

new_audioclip = CompositeAudioClip([audioclip])
videoclip.audio = new_audioclip
videoclip.write_videofile("cooking_voiced.mp4")